import React, { useState } from 'react'
import axios from 'axios';
import {navigate} from '@reach/router';

export default () => {
    const [title, setTitle] = useState(""); 
    const [price, setPrice] = useState("");
    const[description, setDescription] = useState("");

    const onSubmitHandler = e => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/product', {
            title,
            price,
            description,
        })
            .then( (response) => window.location.reload())
            .catch( (err) => console.error(err))
    }

    return (
        <div>
            <form onSubmit={onSubmitHandler}>
                <h2>Product Manager</h2>
                <p>
                    <label>Title</label><br/>
                    <input type="text" onChange = {(e)=>setTitle(e.target.value)}/>
                </p>
                <p>
                    <label>Price</label><br/>
                    <input type="text" onChange = {(e)=>setPrice(e.target.value)}/>
                </p>
                <p>
                    <label>Description</label><br/>
                    <input type="text" onChange = {(e)=>setDescription(e.target.value)}/>
                </p>
            
                <input type="submit" value="Create"/>
            </form>
            
        </div>
    )
}
