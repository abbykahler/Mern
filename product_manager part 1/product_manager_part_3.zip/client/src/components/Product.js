import React, { useEffect, useState } from "react";
import Axios from "axios"; 

const Product = (props) => {

    const [product, setProduct] = useState(null);
    useEffect( () => {
        Axios.get(`http://localhost:8000/api/products/${props.id}`)
        .then( (response) => {setProduct(response.data);})
        .catch( (err) => {console.error(err);})
        }, [props.id]);

    if( product === null){
        return "error"
    }

    return (
            <div>
                    <h3>{product.title}</h3>
                    
        
            </div>
            );
};

export default Product;